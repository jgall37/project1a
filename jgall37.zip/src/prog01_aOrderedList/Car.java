package prog01_aOrderedList;

/*
*
* The Car class is used to store the information of a car's make, year, and price.
* It implements the Comparable interface to allow for easy comparisons of Car objects.
* 
* CSC 1351 Programming Project No 1
* Section 2
*
* @author Joshua Gallo
* @since 3/17/24
*
*/

public class Car implements Comparable<Car> {
	
	private String make;	// Stores the make of the car. Compared with the make of other Cars in the compareTo method.
	private int year;		// Stores the year of the car. Compared with the year of other Cars in the compareTo method.
	private int price;		// Stores the price of the car. Compared with the price of other Cars in the compareTo method.
	
	/*
	*
	* The Car constructor initializes the values of make, year, and price.
	*
	* CSC 1351 Programming Project No 1
	* Section 2
	*
	* @author Joshua Gallo
	* @since 3/17/24
	*
	*/

	public Car(String make, int year, int price) {
		
		this.make = make;
		this.year = year;
		this.price = price;
		
	}
	
	/*
	*
	* The getMake method returns the make of the Car object.
	*
	* CSC 1351 Programming Project No 1
	* Section 2
	*
	* @author Joshua Gallo
	* @since 3/17/24
	*
	*/
	
	public String getMake() {
		
		return make;
		
	}
	
	/*
	*
	* The getYear method returns the year of the Car object.
	*
	* CSC 1351 Programming Project No 1
	* Section 2
	*
	* @author Joshua Gallo
	* @since 3/17/24
	*
	*/
	
	public int getYear() {
		
		return year;
		
	}
	
	/*
	*
	* The getPrice method returns the price of the Car object.
	*
	* CSC 1351 Programming Project No 1
	* Section 2
	*
	* @author Joshua Gallo
	* @since 3/17/24
	*
	*/
	
	public int getPrice() {
		
		return price;
		
	}
	
	/*
	*
	* The compareTo method allows for the comparison of two Car objects.
	* It first compares the make, then the year, then the price of the Car objects.
	*
	* CSC 1351 Programming Project No 1
	* Section 2
	*
	* @author Joshua Gallo
	* @since 3/17/24
	*
	*/
	
	public int compareTo(Car other) {
		
		if (make.compareTo(other.make) != 0) {
			
			return make.compareTo(other.make);
			
		} else if (Integer.compare(year, other.year) != 0) {
			
			return Integer.compare(year, other.year);
			
		} else {
			
			return Integer.compare(price, other.price);
			
		}
		
	}
	
	/*
	*
	* The toString method returns a string containing the make, year, and price of the Car object.
	*
	* CSC 1351 Programming Project No 1
	* Section 2
	*
	* @author Joshua Gallo
	* @since 3/17/24
	*
	*/
	
	public String toString() {
		
		return "Make: " + make + ", Year : " + year + ", Price: " +
				price + ";";
		
	}
	
}
