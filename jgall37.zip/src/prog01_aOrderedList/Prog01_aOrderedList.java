package prog01_aOrderedList;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.Scanner;

/*
*
* The Prog01_aOrderedList class reads an input file and inputs the data on that file into an aOrderedList object.
* Then, using the objects aggregated by the aOrderedList object, it creates a formatted output file using the information of each object.
* 
* CSC 1351 Programming Project No 1
* Section 2
*
* @author Joshua Gallo
* @since 3/17/24
*
*/

public class Prog01_aOrderedList {

	public static void main(String[] args) throws FileNotFoundException {

		Scanner scan = new Scanner(System.in);	//creates a scanner object that allows the user to input file names.
		boolean userIsInputtingFile = true;		//tracks whether the user is currently attempting to input a file into the scanner object.
		String fileName = null;					//tracks the file name that the user will input.
		Scanner fileInfo = null;				//the scanner object used to input data from the file into the ordered list (created with an aOrderedList object).
		
		//allows the user to input the name of the input file. loops until the user either quits or successfully inputs the file.
		while(userIsInputtingFile) {
			
			try {
				
				System.out.print("Enter input filename: ");
				fileName = scan.nextLine();
				fileInfo = getInputFile(fileName);
				userIsInputtingFile = false;
				
			} catch(Exception e) {
				
				System.out.print("The file <" + fileName + "> is not valid. Would you like to continue? <Y/N> ");
				String response = scan.nextLine();
				
				//ensures the user either enters Y or N when prompted to.
				while (!response.equals("N") && !response.equals("Y")) {
					
					System.out.print("<" + response + "> is not a valid option. Would you like to continue? <Y/N> ");
					response = scan.nextLine();
					
				}
				if (response.equals("N")) {
					
					//exits the program when the user does not wish to continue.
					System.exit(0);
					
				}
				
			}
			
		}
		
		String[] tempCarInfo;	//array containing the contents of the current line of the file. Used to add or remove Cars from the ordered list.
		aOrderedList carList = new aOrderedList();	//the ordered list that cars are added to or removed from.
		
		//runs until all of the lines in the file have been read.
		while(fileInfo.hasNext()) {
			
			//splits the data in the current line into the tempCarInfo array.
			tempCarInfo = fileInfo.next().split(",");
			
			//adds the car object to the ordered list. Catches an error if the car information is formatted incorrectly in the input file.
			if (tempCarInfo[0].equals("A") && tempCarInfo.length == 4) {
				
				try {
				
				carList.add(new Car(tempCarInfo[1], Integer.parseInt(tempCarInfo[2]), Integer.parseInt(tempCarInfo[3])));
				
				} catch(Exception e) {
					
					System.out.println("Car information not properly formatted in file.");
					
				}
				
			//removes the car object from the ordered list if it exists. Catches an error if the car information is formatted incorrectly in the input file.
			} else if (tempCarInfo[0].equals("D") && tempCarInfo.length == 3) {
				
				carList.reset();
				boolean searchingForCar = true;		//tracks whether the car object to be deleted has been found in the ordered list.
				
				try {
					
					Car deleteCar = new Car(tempCarInfo[1], Integer.parseInt(tempCarInfo[2]), 0);	//creates a car object to compare to other car objects in the ordered list. If a match is found, the other car object will be removed from the list.
					
					//iterates through the entire list until a match is found or the end of the list is reached.
					while (searchingForCar) {
						
						if (carList.hasNext()) {
							
							Car testCar = (Car) carList.next();		//car object to be compared with deleteCar.
							
							//removes the car object from the list if it is the specified car to be deleted.
							if (testCar.getMake().equals(deleteCar.getMake()) && (testCar.getYear() == deleteCar.getYear())) {
								
								carList.remove();
								searchingForCar = false;
								
							}
							
						//terminates the loop if there was no match.
						} else {
							
							searchingForCar = false;
							
						}
						
					}
					
				} catch(Exception e) {
						
					System.out.println("Car information not properly formatted in file.");
						
				}
				
			}
			
		}
				
		userIsInputtingFile = true;
		fileName = null;
		PrintWriter outputFileInfo = null;	//printwriter object used to transcribe the contents of the ordered list to a specified output file.
		
		//allows the user to input the name of the output file. loops until the user either quits of successfully inputs an output file.
		while(userIsInputtingFile) {
			
			try {
				
				System.out.print("Enter output filename: ");
				fileName = scan.nextLine();
				outputFileInfo = getOutputFile(fileName);
				userIsInputtingFile = false;
				
			} catch(Exception e) {
				
				System.out.print("The file <" + fileName + "> does not exist. Would you like to continue? <Y/N> ");
				String response = scan.nextLine();
				
				//ensures the user either enters Y or N when prompted to.
				while (!response.equals("N") && !response.equals("Y")) {
					
					System.out.print("<" + response + "> is not a valid option. Would you like to continue? <Y/N> ");
					response = scan.nextLine();
					
				}
				if (response.equals("N")) {
					
					//exits the program if the user does not wish to continue.
					System.exit(0);
					
				}
				
			}
			
		}
		
		scan.close();
		
		//prints the number of cars onto the output file.
		outputFileInfo.printf("Number of cars:%5d\n\n", carList.size());
		
		//prints the information of each car in the ordered list onto the output file.
		for (int i = 0; i < carList.size(); i++) {
			
			Car newCar = (Car) carList.get(i);
			outputFileInfo.printf("Make:%15s\nYear:%15d\nPrice:%14s\n\n", newCar.getMake(), newCar.getYear(), "$" + String.format("%,d", newCar.getPrice()));
		
		}
		
		outputFileInfo.close();
		
	}
	
	/*
	*
	* The getInputFile method returns a Scanner object containing the file information.
	*
	* CSC 1351 Programming Project No 1
	* Section 2
	*
	* @author Joshua Gallo
	* @since 3/17/24
	*
	*/
	
	public static Scanner getInputFile(String userPrompt) throws FileNotFoundException {
		
		File inputFile = new File(userPrompt);
		Scanner scanFile = new Scanner(inputFile);
		return scanFile;
		
	}
	
	/*
	*
	* The getOutputFile method returns a PrintWriter object of the file for the information in the ordered list to be transcribed to.
	*
	* CSC 1351 Programming Project No 1
	* Section 2
	*
	* @author Joshua Gallo
	* @since 3/17/24
	*
	*/
	
	public static PrintWriter getOutputFile(String userPrompt) throws FileNotFoundException {
		
		PrintWriter outputFile = new PrintWriter(userPrompt);
		return outputFile;
		
	}

}
