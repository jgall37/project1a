package prog01_aOrderedList;

import java.util.Arrays;

/*
*
* The aOrderedList class is used to aggregate a certain type of Object as long as it implements Comparable.
* It contains methods that add or remove Objects from an array. This array's size can also be increased if it ever fills up.
* This class has an iterator that moves through the array to access the Objects in that array.
* 
* CSC 1351 Programming Project No 1
* Section 2
*
* @author Joshua Gallo
* @since 3/17/24
*
*/

public class aOrderedList {
	
	private final int SIZEINCREMENTS = 20;	//size of the increments for increasing the size of the array oList.
	private Comparable[] oList;				//the ordered list that stores the objects. Objects are added or removed via methods.
	private int listSize;					//the size of the ordered list, increased in increments of SIZEINCREMENTS.
	private int numObjects;					//the number of objects in the ordered list. Used when adding and removing objects.
	private int curr;						//index of the current element accessed via iterator methods
	
	/*
	*
	* The aOrderedList constructor initializes the values of numObjects, listSize, and oList.
	*
	* CSC 1351 Programming Project No 1
	* Section 2
	*
	* @author Joshua Gallo
	* @since 3/17/24
	*
	*/
	
	public aOrderedList() {
		
		numObjects = 0;
		listSize = SIZEINCREMENTS;
		oList = new Comparable[SIZEINCREMENTS];
		
	}
	
	/*
	*
	* The add method adds a new object to the ordered list.
	* If the list is full, a copy is created and the size is incremented by SIZEINCREMENTS.
	* The new object is added to the end of the list, and then the list is sorted.
	*
	* CSC 1351 Programming Project No 1
	* Section 2
	*
	* @author Joshua Gallo
	* @since 3/17/24
	*
	*/
	
	public void add(Comparable newObject) {
		
		if (numObjects >= listSize) {
			
			oList = Arrays.copyOf(oList, oList.length + SIZEINCREMENTS);
			listSize += SIZEINCREMENTS;
			
		}
		
		oList[numObjects] = newObject;
		Arrays.sort(oList, 0, numObjects + 1);
		numObjects++;
	}
	
	/*
	*
	* The toString method returns a string containing the information of each object in the list by calling the object's toString method.
	*
	* CSC 1351 Programming Project No 1
	* Section 2
	*
	* @author Joshua Gallo
	* @since 3/17/24
	*
	*/
	
	public String toString() {
		
		String objectInfo = "";		//used to store the string of each toString method of each object.
		
		for(int i = 0; i < numObjects; i++) {
				
			objectInfo += "[" + oList[i].toString() + "]";
			
			if (i != numObjects - 1) {
				objectInfo += ",";
			}
			
		}
		
		return objectInfo;
		
	}
	
	/*
	*
	* The size method returns the current number of objects in the ordered list.
	*
	* CSC 1351 Programming Project No 1
	* Section 2
	*
	* @author Joshua Gallo
	* @since 3/17/24
	*
	*/
	
	public int size() {
		
		return numObjects;
		
	}
	
	/*
	*
	* The get method returns the object at a specific index in the ordered list.
	*
	* CSC 1351 Programming Project No 1
	* Section 2
	*
	* @author Joshua Gallo
	* @since 3/17/24
	*
	*/
	
	public Comparable get(int index) {
		
		return oList[index];
		
	}
	
	/*
	*
	* The isEmpty method returns whether the ordered list is empty or not.
	*
	* CSC 1351 Programming Project No 1
	* Section 2
	*
	* @author Joshua Gallo
	* @since 3/17/24
	*
	*/
	
	public boolean isEmpty() {
		
		return numObjects == 0;
		
	}
	
	/*
	*
	* The reset method resets the position of the iterator variable curr back to the start of the array right before the first element.
	*
	* CSC 1351 Programming Project No 1
	* Section 2
	*
	* @author Joshua Gallo
	* @since 3/17/24
	*
	*/
	
	public void reset() {
		
		curr = -1;
		
	}
	
	/*
	*
	* The next method returns the next object after the current position of the variable curr.
	*
	* CSC 1351 Programming Project No 1
	* Section 2
	*
	* @author Joshua Gallo
	* @since 3/17/24
	*
	*/
	
	public Comparable next() {
		
		curr++;
		return oList[curr];
		
	}
	
	/*
	*
	* The hasNext method returns whether or not there is an object at the next position in the ordered list.
	*
	* CSC 1351 Programming Project No 1
	* Section 2
	*
	* @author Joshua Gallo
	* @since 3/17/24
	*
	*/
	
	public boolean hasNext() {
		
		return curr + 1 < numObjects;
		
	}
	
	/*
	*
	* The remove method removes the last element accessed by the next method. 
	*
	* CSC 1351 Programming Project No 1
	* Section 2
	*
	* @author Joshua Gallo
	* @since 3/17/24
	*
	*/
	
	public void remove() {
		
		if (curr < numObjects) {
			
			for (int i = curr; i < numObjects - 1; i++) {
				
				oList[i] = oList[i + 1];
				
			}
			
			oList[numObjects - 1] = null;
			
			numObjects--;
			
		}
		
	}

}
